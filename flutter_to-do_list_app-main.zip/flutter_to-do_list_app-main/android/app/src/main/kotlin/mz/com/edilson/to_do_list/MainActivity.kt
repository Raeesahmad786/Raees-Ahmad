package mz.com.edilson.to_do_list

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
